﻿using DemoLogin.Models;
using DemoLogin.Models.Request;
using DemoLogin.Models.Response;
using Infrastructure.Abstractions;
using Infrastructure.Models.Entities;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace DemoLogin.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        private readonly IUnitOfWork _unitOfWork;

        public HomeController(ILogger<HomeController> logger, IUnitOfWork unitOfWork)
        {
            _logger = logger;
            _unitOfWork = unitOfWork;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        [Route("/account/do-register")]
        public async Task<IActionResult> DoRegister(RegisterRequest request)
        {
            var accountFind = await _unitOfWork.Account.HandleLoginAsync(request.Email);

            if (accountFind == null)
            {
                var account = new Account
                {
                    Email = request.Email,
                    Password = request.Password,
                    Address = request.Address,
                    IsActived = true,
                    IsDeleted = false,
                };

                var registerResult = await _unitOfWork.Account.CreateAsync(account);

                if (registerResult > 0)
                {
                    return Ok(new ResponseObject { Code = 0, Message = "Register success!", Data = registerResult });
                }

                return Ok(new ResponseObject { Code = -1, Message = "Register failed! Please try again!" });
            }

            return Ok(new ResponseObject { Code = -1, Message = "Email is already exist!" });
        }

        [HttpPost]
        [Route("/account/login")]
        public async Task<IActionResult> DoLogin(LoginRequest request)
        {
            var accountFind = await _unitOfWork.Account.HandleLoginAsync(request.Email);

            if (accountFind != null)
            {
                if (accountFind.Password.Equals(request.Password))
                {
                    return Ok(new ResponseObject<Account> { Code = 0, Message = "Login success!", Data = accountFind });
                }
            }

            return Ok(new ResponseObject { Code = -1, Message = "Email or password is invalid!" });
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
